<?php $__env->startSection('header'); ?>
    Start New Production
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                <form method="POST" action="<?php echo e(route('bakery.production.store')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    <!-- Batch Name -->
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">Batch Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Production Line -->
                    <div>
                        <label for="line" class="block text-sm font-medium text-gray-700">Production Line</label>
                        <input type="text" name="line" id="line" value="<?php echo e(old('line')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                        <?php $__errorArgs = ['line'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Scheduled Start -->
                    <div>
                        <label for="scheduled_start" class="block text-sm font-medium text-gray-700">Scheduled Start</label>
                        <input type="datetime-local" name="scheduled_start" id="scheduled_start" value="<?php echo e(old('scheduled_start')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                        <?php $__errorArgs = ['scheduled_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Quantity -->
                    <div>
                        <label for="quantity" class="block text-sm font-medium text-gray-700">Quantity</label>
                        <input type="number" name="quantity" id="quantity" min="1" value="<?php echo e(old('quantity')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Ingredients -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Ingredients Used</label>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center space-x-2">
                                    <input type="checkbox" id="ingredient_<?php echo e($ingredient->id); ?>" name="ingredients[<?php echo e($loop->index); ?>][id]" value="<?php echo e($ingredient->id); ?>" <?php echo e(old('ingredients.'.$loop->index.'.id') == $ingredient->id ? 'checked' : ''); ?>>
                                    <label for="ingredient_<?php echo e($ingredient->id); ?>" class="flex-1"><?php echo e($ingredient->name); ?> (<?php echo e($ingredient->unit); ?>)</label>
                                    <input type="number" step="0.01" min="0" name="ingredients[<?php echo e($loop->index); ?>][quantity]" value="<?php echo e(old('ingredients.'.$loop->index.'.quantity')); ?>" placeholder="Qty" class="w-24 rounded-md border-gray-300 shadow-sm">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php $__errorArgs = ['ingredients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Notes -->
                    <div>
                        <label for="notes" class="block text-sm font-medium text-gray-700">Notes</label>
                        <textarea name="notes" id="notes" rows="3" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"><?php echo e(old('notes')); ?></textarea>
                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex justify-end mt-6">
                        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Start Production
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.bakery-manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/armandshematsi/Desktop/Bimbo-whole-system/Bimbo-implementation/resources/views/bakery/production/start.blade.php ENDPATH**/ ?>