<?php $__env->startSection('header'); ?>
    Production Batches
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between mb-4">
        <h2 class="text-xl font-semibold">Production Batches</h2>
        <a href="<?php echo e(route('bakery.batches.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">New Batch</a>
    </div>
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white">
            <thead>
                <tr>
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Status</th>
                    <th class="px-4 py-2">Scheduled Start</th>
                    <th class="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($batch->name); ?></td>
                        <td class="border px-4 py-2"><?php echo e(ucfirst($batch->status)); ?></td>
                        <td class="border px-4 py-2"><?php echo e($batch->scheduled_start); ?></td>
                        <td class="border px-4 py-2 flex space-x-2">
                            <a href="<?php echo e(route('bakery.batches.show', $batch)); ?>" class="text-blue-600 hover:underline">View</a>
                            <a href="<?php echo e(route('bakery.batches.edit', $batch)); ?>" class="text-yellow-600 hover:underline">Edit</a>
                            <form action="<?php echo e(route('bakery.batches.destroy', $batch)); ?>" method="POST" onsubmit="return confirm('Delete this batch?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4">
        <?php echo e($batches->links()); ?>

    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.bakery-manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/armandshematsi/Desktop/Bimbo-whole-system/Bimbo-implementation/resources/views/bakery/batches/index.blade.php ENDPATH**/ ?>