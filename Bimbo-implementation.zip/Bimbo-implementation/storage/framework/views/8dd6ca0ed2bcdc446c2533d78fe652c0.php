<?php $__env->startSection('header'); ?>
    New Production Batch
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-xl mx-auto">
        <form method="POST" action="<?php echo e(route('bakery.batches.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                <select name="status" id="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    <option value="planned"<?php echo e(old('status') == 'planned' ? ' selected' : ''); ?>>Planned</option>
                    <option value="active"<?php echo e(old('status') == 'active' ? ' selected' : ''); ?>>Active</option>
                    <option value="completed"<?php echo e(old('status') == 'completed' ? ' selected' : ''); ?>>Completed</option>
                    <option value="cancelled"<?php echo e(old('status') == 'cancelled' ? ' selected' : ''); ?>>Cancelled</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="scheduled_start" class="block text-sm font-medium text-gray-700">Scheduled Start</label>
                <input type="datetime-local" name="scheduled_start" id="scheduled_start" value="<?php echo e(old('scheduled_start')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['scheduled_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="actual_start" class="block text-sm font-medium text-gray-700">Actual Start</label>
                <input type="datetime-local" name="actual_start" id="actual_start" value="<?php echo e(old('actual_start')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['actual_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="actual_end" class="block text-sm font-medium text-gray-700">Actual End</label>
                <input type="datetime-local" name="actual_end" id="actual_end" value="<?php echo e(old('actual_end')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['actual_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="notes" class="block text-sm font-medium text-gray-700">Notes</label>
                <textarea name="notes" id="notes" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"><?php echo e(old('notes')); ?></textarea>
                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Create Batch</button>
            <a href="<?php echo e(route('bakery.batches.index')); ?>" class="ml-2 text-gray-600 hover:underline">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.bakery-manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/armandshematsi/Desktop/Bimbo-whole-system/Bimbo-implementation/resources/views/bakery/batches/create.blade.php ENDPATH**/ ?>