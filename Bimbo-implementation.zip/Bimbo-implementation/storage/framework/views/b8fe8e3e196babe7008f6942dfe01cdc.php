<?php $__env->startSection('header'); ?>
    Machines
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-between mb-4">
        <h2 class="text-xl font-semibold">Machines</h2>
        <a href="<?php echo e(route('bakery.machines.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Add Machine</a>
    </div>
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white">
            <thead>
                <tr>
                    <th class="px-4 py-2">Name</th>
                    <th class="px-4 py-2">Type</th>
                    <th class="px-4 py-2">Status</th>
                    <th class="px-4 py-2">Last Maintenance</th>
                    <th class="px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border px-4 py-2"><?php echo e($machine->name); ?></td>
                        <td class="border px-4 py-2"><?php echo e($machine->type); ?></td>
                        <td class="border px-4 py-2"><?php echo e(ucfirst($machine->status)); ?></td>
                        <td class="border px-4 py-2"><?php echo e($machine->last_maintenance_at ?? '-'); ?></td>
                        <td class="border px-4 py-2 flex space-x-2">
                            <a href="<?php echo e(route('bakery.machines.show', $machine)); ?>" class="text-blue-600 hover:underline">View</a>
                            <a href="<?php echo e(route('bakery.machines.edit', $machine)); ?>" class="text-yellow-600 hover:underline">Edit</a>
                            <form action="<?php echo e(route('bakery.machines.destroy', $machine)); ?>" method="POST" onsubmit="return confirm('Delete this machine?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4">
        <?php echo e($machines->links()); ?>

    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.bakery-manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/armandshematsi/Desktop/Bimbo-whole-system/Bimbo-implementation/resources/views/bakery/machines/index.blade.php ENDPATH**/ ?>