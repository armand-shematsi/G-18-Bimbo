<?php $__env->startSection('header'); ?>
    Schedule Maintenance Task
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-xl mx-auto">
        <form method="POST" action="<?php echo e(route('bakery.maintenance-tasks.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="machine_id" class="block text-sm font-medium text-gray-700">Machine</label>
                <select name="machine_id" id="machine_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    <option value="">Select Machine</option>
                    <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($machine->id); ?>"<?php echo e(old('machine_id') == $machine->id ? ' selected' : ''); ?>><?php echo e($machine->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['machine_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="scheduled_for" class="block text-sm font-medium text-gray-700">Scheduled For</label>
                <input type="datetime-local" name="scheduled_for" id="scheduled_for" value="<?php echo e(old('scheduled_for')); ?>" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['scheduled_for'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" id="description" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                <select name="status" id="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                    <option value="scheduled"<?php echo e(old('status') == 'scheduled' ? ' selected' : ''); ?>>Scheduled</option>
                    <option value="completed"<?php echo e(old('status') == 'completed' ? ' selected' : ''); ?>>Completed</option>
                    <option value="overdue"<?php echo e(old('status') == 'overdue' ? ' selected' : ''); ?>>Overdue</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="completed_at" class="block text-sm font-medium text-gray-700">Completed At</label>
                <input type="datetime-local" name="completed_at" id="completed_at" value="<?php echo e(old('completed_at')); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm">
                <?php $__errorArgs = ['completed_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-red-600 text-sm"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Schedule Task</button>
            <a href="<?php echo e(route('bakery.maintenance-tasks.index')); ?>" class="ml-2 text-gray-600 hover:underline">Cancel</a>
        </form>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.bakery-manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/armandshematsi/Desktop/Bimbo-whole-system/Bimbo-implementation/resources/views/bakery/maintenance_tasks/create.blade.php ENDPATH**/ ?>